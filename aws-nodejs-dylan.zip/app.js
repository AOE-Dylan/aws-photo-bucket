let mapKeys = (x) => {x.key};

const imgs = (responseData) => {
    console.log(responseData);
    let pics = responseData.message;
    console.log(pics);
    $('#data').append(pics);
};

let getImages = path => {
  $.ajax({
    url: path,
    type : "GET",
    success : get = (data) => imgs(data),
  })
  console.log(get);
};

$("#getData").click(
  getImages("https://nq2x144zp1.execute-api.us-west-2.amazonaws.com/dev/users/photos")
);